# task3
def dfs(graph, current_city, visited):

    if current_city not in visited:
        # print(current_city,end=" ")
        out.write(str(current_city)+" ")
        visited.add(current_city)
        if current_city in graph:
            for adjacent_city in graph[current_city]:
                dfs(graph, adjacent_city, visited)

        # return visited


in_file = open('input3.txt', 'r')
out = open('output3.txt', 'w')
s = in_file.readline().split()
l = []
d = {}

for i in range(int(s[1])):
    k = in_file.readline().split()
    l.append(k)
    if l[i][0] not in d:
        d[l[i][0]] = [l[i][1]]
    else:
        d[l[i][0]].append(l[i][1])
    if l[i][1] not in d:
        d[l[i][1]] = [l[i][0]]
    else:
        d[l[i][1]].append(l[i][0])
start = list(d.keys())[0]
visited = set()
print(dfs(d, start, visited))
out.close()
