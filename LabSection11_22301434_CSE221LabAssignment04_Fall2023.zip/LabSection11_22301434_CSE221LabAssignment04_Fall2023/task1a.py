
in_file = open('input1a.txt', 'r')
out_file = open('output1a.txt', 'w')
s = in_file.readline().split()
l = []
d = {}

for i in range(int(s[1])):
    k = in_file.readline().split()
    l.append(k)
    if l[i][0] not in d:
        d[l[i][0]] = [(int(l[i][1]), int(l[i][2]))]
    else:
        d[l[i][0]].append((int(l[i][1]), int(l[i][2])))
print(d)
print(l)
for i in range(int(s[0])):
    if str(i) not in d:
        print()
        out_file.write(f"{i}:\n")
    else:
        l1 = str(d[str(i)])
        l1 = l1[1:len(l1)-1]

        out_file.write(f"{i}: {l1}\n")
out_file.close()
