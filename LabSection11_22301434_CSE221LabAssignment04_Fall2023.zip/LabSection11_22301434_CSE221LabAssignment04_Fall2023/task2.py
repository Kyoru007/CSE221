def bfs(graph, vertex):
    visited = set()
    visited.add(vertex)
    queue = [vertex]
    while queue:
        current_city = queue.pop(0)
        out.write(str(current_city)+" ")
        if current_city in graph:
            for adjacent_city in graph[current_city]:
                if adjacent_city not in visited:
                    visited.add(adjacent_city)
                    queue.append(adjacent_city)

    return queue


in_file = open('input2.txt', 'r')
out = open('output2.txt', 'w')
s = in_file.readline().split()
l = []
d = {}

for i in range(int(s[1])):
    k = in_file.readline().split()
    l.append(k)
    if l[i][0] not in d:
        d[l[i][0]] = [l[i][1]]
    else:
        d[l[i][0]].append(l[i][1])
start = list(d.keys())[0]
print(bfs(d, start))
out.close()
