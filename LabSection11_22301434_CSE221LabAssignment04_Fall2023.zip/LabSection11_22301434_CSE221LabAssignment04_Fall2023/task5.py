def short(graph, vertex, arr, city):
    visited = set()
    visited.add(vertex)
    queue = [vertex]
    while queue:
        current_city = queue.pop(0)
        out.write(str(current_city)+" ")
        if current_city in graph:
            for adjacent_city in graph[current_city]:
                if adjacent_city not in visited:
                    visited.add(adjacent_city)
                    arr[int(adjacent_city)] = current_city
                    queue.append(adjacent_city)
    i = int(city)
    k = ""
    print(i)
    count = -1
    while int(i) > 0:
        k += f" {i}"
        i = int(arr[i])
        count += 1
    k = k[::-1]
    out.write(f"Time {count} \nShortest Path:{k}")
    return queue, arr


in_file = open('input5.txt', 'r')
out = open('output5.txt', 'w')
s = in_file.readline().split()
l = []
d = {}

for i in range(int(s[1])):
    k = in_file.readline().split()
    l.append(k)
    if int(l[i][0]) not in d:
        d[int(l[i][0])] = [int(l[i][1])]
    else:
        d[int(l[i][0])].append(int(l[i][1]))
    if int(l[i][1]) not in d:
        d[int(l[i][1])] = [int(l[i][0])]
    else:
        d[int(l[i][1])].append(int(l[i][0]))
print(d)
start = list(d.keys())[0]
print(short(d, start, [0]*(int(s[0])+1), s[2]))
out.close()
