def cycle_det(graph, city, visited, stack):
    visited.add(city)
    stack.add(city)
    if city in graph:
        for neighbor in graph[city]:
            if neighbor not in visited:
                if cycle_det(graph, neighbor, visited, stack):
                    return True
            elif neighbor in stack:
                return True
    stack.remove(city)
    return False


def cycle_check(graph):
    visited = set()
    stack = set()
    for i in list(graph.keys()):
      # if i not in visited:
        if cycle_det(graph, i, visited, stack):
            return True
    return False


inp = open("input4.txt", "r")
out = open("output4.txt", "w")
s = inp.readline().split()
l = []
d = {}
for i in range(int(s[1])):
    k = inp.readline().split()
    l.append(k)
    if l[i][0] not in d:
        d[l[i][0]] = [l[i][1]]
    else:
        d[l[i][0]].append(l[i][1])

cycle = cycle_check(d)
if cycle == True:
    out.write("YES")
elif cycle == False:
    out.write("NO")
out.close()
