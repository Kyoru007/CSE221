
inp = open("input1.txt", "r")
out = open("output1.txt", "w")
arr = list(map(int, inp.readline().split()))
graph = [[0]*(arr[0]+1) for _ in range(arr[0]+1)]
for i in range(arr[1]):
    arr1 = list(map(int, inp.readline().split()))
    graph[arr1[0]][arr1[1]] = arr1[2]
for j in range(len(graph)):
    out.write(f"{' '.join(map(str, graph[j]))} \n")
out.close()
