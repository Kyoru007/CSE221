# task6
def partition(arr, low, high):
    pivot = arr[high]
    swap = low - 1

    for j in range(low, high):
        if arr[j] <= pivot:
            swap += 1
            arr[swap], arr[j] = arr[j], arr[swap]

    arr[swap + 1], arr[high] = arr[high], arr[swap + 1]
    return swap-1


def kth_smallest(arr, low, high, k):
    if low <= high:
        pivot_index = partition(arr, low, high)
        if pivot_index == k-1:
            return arr[pivot_index]
        elif pivot_index > k-1:
            return kth_smallest(arr, low, pivot_index - 1, k)
        else:
            return kth_smallest(arr, pivot_index + 1, high, k)
# Input reading


inp = open("input6.txt", "r")
n = int(inp.readline())
arr = list(map(int, inp.readline().split()))
arr1 = []
for i in arr:
    arr1.append(i)
print(arr)
q = int(inp.readline())
queries = []
for _ in range(q):
    k = int(inp.readline())
    print(k)
    query = kth_smallest(arr, 0, n-1, k)
    print(arr)
    queries.append(query)
print(queries)
out = open("output6.txt", "w")
for val in queries:
    out.write(str(val)+"\n")
out.close()
