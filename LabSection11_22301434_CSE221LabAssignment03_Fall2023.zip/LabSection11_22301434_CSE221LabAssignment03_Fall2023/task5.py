# task5
def pivot(l, pivot_index, end_index):
    swap_index = pivot_index
    for i in range(pivot_index+1, end_index+1):
        if l[i] <= l[pivot_index]:
            swap_index += 1
            l[swap_index], l[i] = l[i], l[swap_index]
    l[swap_index], l[pivot_index] = l[pivot_index], l[swap_index]
    return swap_index


def quicksort(l, left, right):
    if left < right:
        pivot_index = pivot(l, left, right)
        quicksort(l, left, pivot_index-1)
        quicksort(l, pivot_index+1, right)
    return l


inp = open("input5.txt", "r")
out = open("output5.txt", "w")
n = int(inp.readline())
arr = list(map(int, inp.readline().split()))

arr = quicksort(arr, 0, n-1)
for i in arr:
    out.write(str(i)+" ")
out.close()
