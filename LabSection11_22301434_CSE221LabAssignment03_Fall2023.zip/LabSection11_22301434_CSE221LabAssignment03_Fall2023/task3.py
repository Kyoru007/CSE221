def paircon(arr):
    if len(arr) <= 1:
        return arr, 0
    mid = len(arr)//2

    left, pairs_left = paircon(arr[:mid])
    right, pairs_right = paircon(arr[mid:])

    merged = []

    i = 0
    j = 0

    pairs = pairs_left+pairs_right
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            merged.append(left[i])
            i += 1
        else:
            merged.append(right)
            j += 1
            pairs += len(left)-i
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged, pairs


inp = open("input3.txt", "r")
n = int(inp.readline())
out = open("output3.txt", "w")
arr = list(map((int, inp.readline().split())))
paired_heights, pairs = paircon(arr)
out.write(str(pairs))
out.close()
