def div_con(arr, left, right):
    if left == right:

        return arr[left]
    mid = (left+right)//2

    l1 = div_con(arr, left, mid)
    l2 = div_con(arr, mid+1, right)
    return max(l1, l2)


div_con([5, 1, 32, 8, 5, 7, 2, 6], 0, 7)
inp = open("input2.txt", "r")
out = open("output2.txt", "w")
n = int(inp.readline())
arr = list(map(int, inp.readline().split()))
ans = div_con(arr, 0, n-1)
out.write(str(ans)+" ")
out.close()
