def max_sum(arr, start, end):
    if start == end:
        return arr[start], start, start
    mid = (start+end)//2

    left_max, left_i, left_j = max_sum(arr, start, mid)
    right_max, right_i, right_j = max_sum(arr, mid + 1, end)

    max_right_value = 0
    for i in range(mid+1, end+1):
        if arr[i]**2 > max_right_value:
            max_right_value = arr[i]**2

    max_sum_val = max(left_max, right_max)
    max_i, max_j = left_i, left_j

    for i in range(start, mid+1):
        a_i = arr[i]
        max_right_sq = max_right_value**2
        cur_sum = a_i + max_right_sq
        if cur_sum > max_sum_val:
            max_sum_val = cur_sum
            max_i = i
            max_j = right_j
    return max_sum_val, max_i, max_j


inp = open("input4.txt", "r")
out = open("output4.txt", "w")
n = int(inp.readline())
arr = list(map(int, inp.readline().split()))
max_sum = max_sum(arr, 0, n-1)
out.write(str(max_sum))
