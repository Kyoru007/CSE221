inp_file=open('input4.txt','r')
out_file=open('output4.txt','w')
s=inp_file.readline()
t=int(s)
l1=[]
for i in range(t):
  s=inp_file.readline()
  l1.append(s.split())

l1.sort()
for i in range(len(l1)-1):
  max_id=i
  for j in range(i+1,len(l1)):
      # if l2[max_id]<l2[j]:
      #   l2[max_id],l2[j]=l2[j],l2[max_id]
      #   l1[max_id],l1[j]=l1[j],l1[max_id]
    if l1[max_id][0]==l1[j][0] :
        if l1[max_id][-1] <l1[j][-1]:
          l1[max_id],l1[j]=l1[j],l1[max_id]
for i in range(t):

    out_file.write(" ".join(l1[i])+"\n")
out_file.close()
print(l1)