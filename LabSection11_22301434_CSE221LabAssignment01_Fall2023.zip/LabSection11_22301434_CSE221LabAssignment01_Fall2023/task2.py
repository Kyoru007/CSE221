inp_file=open('input2.txt','r')
out_file=open('output2.txt','w')
s=inp_file.readline()
l=inp_file.readline().split()
l=[int(i) for i in l]
print(l)
flag=True
for i in range(int(s)-1):
    for j in range(int(s)-i-1):
        if l[j]>l[j+1]:
            l[j],l[j+1]=l[j+1],l[j]
  
for i in range(len(l)):
  out_file.write(str(l[i])+" ")
out_file.close()