inp_file = open('input1a.txt', 'r')
out_file = open('output1a.txt', 'w')

s = inp_file.readline()
for i in range(int(s)):
    n = inp_file.readline()
    if int(n) % 2 == 0:
        print(f"{int(n)} is an Even number.")
        out_file.write(f"{int(n)} is an Even number.\n")
    else:
        out_file.write(f"{int(n)} is an Odd number.\n")
        print(f"{int(n)} is an Odd number.")
out_file.flush()
out_file.close()
