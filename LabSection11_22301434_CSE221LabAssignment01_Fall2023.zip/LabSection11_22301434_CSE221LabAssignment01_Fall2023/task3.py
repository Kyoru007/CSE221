
inp_file=open('input3.txt','r')
out_file=open('output3.txt','w')
s=inp_file.readline()
l1=inp_file.readline().split()
l1=[int(i) for i in l1]
l2=inp_file.readline().split()
l2=[int(i) for i in l2]
print(l1,"\n",l2,end="")
for i in range(len(l1)-1):
  max_id=i
  for j in range(i+1,len(l1)):
      if l2[max_id]<l2[j]:
        l2[max_id],l2[j]=l2[j],l2[max_id]
        l1[max_id],l1[j]=l1[j],l1[max_id]
      elif l2[max_id]==l2[j] :
        if l1[max_id]>l1[j]:
          l1[max_id],l1[j]=l1[j],l1[max_id]
for i in range(len(l1)):
  out_file.write(f"ID: {str(l1[i])} Mark: {str(l2[i])} \n")
out_file.close()