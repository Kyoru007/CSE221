
inp_file = open('input1b.txt', 'r')
out_file = open('output1b.txt', 'w')
s = inp_file.readline()
print(s)
t = int(s)
for i in range(t):
    s = inp_file.readline()
    s = s.split()
    if s[2] == "+":
        out_file.write(
            f"The result of {s[1]} {s[2]} {s[3]} is {int(s[1])+int(s[3])}\n")
    elif s[2] == "-":
        out_file.write(
            f"The result of {s[1]} {s[2]} {s[3]} is {int(s[1])-int(s[3])}\n")
    elif s[2] == "*":
        out_file.write(
            f"The result of {s[1]} {s[2]} {s[3]} is {int(s[1])*int(s[3])}\n")
    elif s[2] == "/":
        out_file.write(
            f"The result of {s[1]} {s[2]} {s[3]} is {int(s[1])/int(s[3])}\n")

    print(s)
out_file.close()
