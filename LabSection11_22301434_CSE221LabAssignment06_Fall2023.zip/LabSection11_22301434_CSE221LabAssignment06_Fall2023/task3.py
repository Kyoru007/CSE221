def dfs(graph, friend, circle):
    circle.append(friend)
    size = 1
    for neighbour in graph[friend]:
        if neighbour not in circle:
            size += dfs(graph, neighbour, circle)
    return size


def friend_counter(N, peeps):
    graph = {}
    circle_sizes = []

    for friend1, friend2 in peeps:
        if friend1 not in graph:
            graph[friend1] = [friend2]
        elif friend1 in graph:
            graph[friend1].append(friend2)
        if friend2 not in graph:
            graph[friend2] = [friend1]
        elif friend2 in graph:
            graph[friend2].append(friend1)
        visited = []
        circle_size = dfs(graph, friend1, visited)
        circle_sizes.append(circle_size)

    return circle_sizes


inp = open("input3.txt", "r")
out = open("output3.txt", "w")
n, e = map(int, inp.readline().split())
peeps = [tuple(map(int, inp.readline().split())) for i in range(e)]
result = friend_counter(n, peeps)
for i in result:
    out.write(f"{i}\n")
print(result)
