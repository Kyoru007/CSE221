def kripon(graph, source):
    distances = [-1]*len(graph)
    distances[source-1] = 0

    priority_queue = [(source, 0)]

    while priority_queue:
        u, d = priority_queue.pop(0)
        if u in graph:
            for v, weight in graph[u]:
                sum = d+weight
                if distances[v-1] == -1 or distances[v-1] > sum:
                    distances[v-1] = sum
                    priority_queue.insert(0, (v, weight))
                    print(distances)
    return distances


inp = open("input1.txt", "r")

lines = inp.readline()
n, e = map(int, lines.split())
# N, M = map(int, lines[0].split())
graph = {}
for i in range(e):
    u, v, w = map(int, inp.readline().split())
    if u not in graph:
        graph[u] = [(v, w)]
    else:
        graph[u].append((v, w))

# graph = {i: [] for i in range(1, N + 1)}
# for line in lines[1:M + 1]:
#     u, v, w = map(int, line.split())
#     graph[u].append((v, w))
# print(lines[M+1])
source, start_b = map(int, inp.readline().split())

# Find shortest distances using Dijkstra's algorithm
distances = kripon(graph, source)
out = open("output.txt", "w")
out.write(" ".join(map(str, distances)))

# Write the result to output.txt
# with open("output.txt", "w") as file:
#     file.write(" ".join(map(str, distances)))
