def mapper(graph, start, n):
    distances = [float('inf')]*(n+1)

    distances[start] = 0
    print(distances)
    priority_queue = [(start, 0)]
    while priority_queue:
        u, d = priority_queue.pop(0)
        if u in graph:
            for v, weight in graph[u]:
                sum = d+weight
                if distances[v] == -1 or distances[v] > sum:
                    distances[v] = sum
                    priority_queue.insert(0, (v, sum))
    print(distances)
    return distances


def meet_pointer(graph, start_a, start_b, n):
    print(n)
    distances_a = mapper(graph, start_a, n)
    distances_b = mapper(graph, start_b, n)

    min_time = float('inf')
    meet = -1
    for node in range(1, n+1):
        if node != start_a or node != start_b:
            time = max(distances_a[node], distances_b[node])

            print("TIME", time)
            print("NODE", node)
            if time < min_time:
                min_time = time
                meet = node
    print(min_time, meet)
    if min_time != float("inf"):
        print(min_time, meet)
        return f"Time:{min_time}\n", f"Node:{meet}"
    else:
        return "", "IMPOSSIBLE"


inp = open("input2.txt", "r")

lines = inp.readline()
n, e = map(int, lines.split())

graph = {}
for i in range(e):
    u, v, w = map(int, inp.readline().split())
    if u not in graph:
        graph[u] = [(v, w)]
    else:
        graph[u].append((v, w))

print(graph)
start_a, start_b = map(int, inp.readline().split())

distances = meet_pointer(graph, start_a, start_b, n)
out = open("output.txt", "w")
out.write(distances[0])
out.write(distances[1])
