def find_parent(parent, i):
    if parent[i] == i:
        return i
    return find_parent(parent, parent[i])


def union(parent, rank, x, y):
    x_root = find_parent(parent, x)
    y_root = find_parent(parent, y)

    if rank[x_root] < rank[y_root]:
        parent[x_root] = y_root
    elif rank[y_root] > rank[x_root]:
        parent[y_root] = x_root
    else:
        parent[x_root] = y_root
        rank[y_root] += 1


def kruskal(graph, n, edges):
    print(edges)
    parent = [i for i in range(n+1)]
    rank = [0 for i in range(n+1)]
    edges.sort(key=lambda x: x[2])

    min_cost = 0
    for edge in edges:
        u, v, weight = edge
        if find_parent(parent, u) != find_parent(parent, v):
            union(parent, rank, u, v)
            min_cost += weight
    print("min", min_cost)
    return min_cost


inp = open("input4.txt", "r")
out = open("output4.txt", "w")
n, e = map(int, inp.readline().split())
graph = {}
edges = []
for i in range(e):
    u, v, w = map(int, inp.readline().split())
    edges.append((u, v, w))
    if u not in graph:
        graph[u] = [(v, w)]
    else:
        graph[u].append((v, w))
    if v not in graph:
        graph[v] = [(u, w)]
    else:
        graph[v].append((u, w))
out.write(f"{kruskal(graph, n, edges)}")
