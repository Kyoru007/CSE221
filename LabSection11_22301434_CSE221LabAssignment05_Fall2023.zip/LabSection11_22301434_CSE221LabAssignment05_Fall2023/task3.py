def dfs(graph, current_city, visited, stack):
    visited.append(current_city)
    if current_city in graph:
        for adjacent_city in graph[current_city]:
            if adjacent_city not in visited:
                dfs(graph, adjacent_city, visited, stack)
        stack.append(current_city)


def dfs_scc(graph, current_city, visited, scc):
    visited.append(current_city)
    scc.append(current_city)
    print(current_city)
    if current_city in graph:
        for adjacent_city in graph[current_city]:
            if adjacent_city not in visited:
                dfs_scc(graph, adjacent_city, visited, scc)


def transpose(graph):
    graphT = {}
    n = max(graph.keys())
    for k in graph.keys():
        for v in graph[k]:
            if v not in graphT:
                graphT[v] = [k]
            else:
                graphT[v].append(k)
    return graphT


def scc(graph):
    visited = []
    stack = []

    for node in graph.keys():
        if node not in visited:
            dfs(graph, node, visited, stack)
    transposed = transpose(graph)
    print(transposed)
    visited = []
    scc_visited = []
    while stack:
        node = stack.pop()
        if node not in visited:
            scc = []
            dfs_scc(transposed, node, visited, scc)
            print(scc)
            scc_visited.append(scc)

    return scc_visited


in_file = open('input3.txt', 'r')
out = open('output3.txt', 'w')
s = in_file.readline().split()
l = []
d = {}

for i in range(int(s[1])):
    k = in_file.readline().split()
    l.append(k)
    if l[i][0] not in d:
        d[l[i][0]] = [l[i][1]]
    else:
        d[l[i][0]].append(l[i][1])

scc = scc(d)
for i in scc:
    print(i)
    out.write(" ".join(i)+" \n")

out.close()
