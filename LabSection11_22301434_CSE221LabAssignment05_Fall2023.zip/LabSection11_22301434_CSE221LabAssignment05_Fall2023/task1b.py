def bfs_sequencer(n, courses):
    graph = {}
    inorder = [0]*(n+1)
    for i in range(1, n + 1):
        graph[i] = []

    for prerequisite in courses:
        graph[prerequisite[0]].append(prerequisite[1])
        inorder[prerequisite[1]] += 1

    queue = []
    result = []
    for i in range(1, n+1):
        if inorder[i] == 0:
            queue.append(i)
    print("inorder", inorder)
    while queue:
        print("queue", queue)
        course = queue.pop(0)
        print("result", result)
        print("queue", queue)
        print(course)
        print(inorder)
        # out.write(str(course)+" ")
        result.append(course)
        for next_course in graph[course]:
            print(inorder)
            print(next_course)

            inorder[next_course] -= 1
            print(inorder)
            if inorder[next_course] == 0:
                print(inorder)

                queue.append(next_course)
                print("queue : ", queue)

            print("Indegree:", inorder, "next_course", next_course)
            # if inorder[next_course]==0:
            #   queue.append(next_course)
            #   print("queue : ",queue)
    # result=result[::-1]
    # print(result[::-1])
    print(result)
    if len(result) == n:
        result = [str(i) for i in result]
        print(result)
        st = " ".join(result)
        out.write(st)
        return str(result)[1:len(result)+1]

    else:
        out.write("IMPOSSIBLE")


inp = open("input1b.txt", "r")
out = open("output1b.txt", "w")
n, e = map(int, inp.readline().split())
courses = [tuple(map(int, inp.readline().split())) for i in range(e)]
# N, M = map(int, file.readline().split())
# prerequisites = [tuple(map(int, file.readline().split())) for _ in range(M)]
bfs_sequencer(n, courses)


out.close()
