def dfs_sequencer(course, prerequisites, visited, indegree, result):
    if course not in visited:
        visited.append(course)
        result.append(course)

    if course in prerequisites:
        for neighbor in prerequisites[course]:
            indegree[int(neighbor)] -= 1
            if indegree[int(neighbor)] == 0 and neighbor not in visited:
                dfs_sequencer(neighbor, prerequisites,
                              visited, indegree, result)


def dfs_course_sequencer(n, prerequisites):
    result = []
    visited = []
    indegree = [0]*(n+1)
    for neighbors in prerequisites.values():
        for neighbor in neighbors:
            indegree[int(neighbor)] += 1

    for course in prerequisites.keys():
        if indegree[int(course)] == 0 and course not in visited:
            dfs_sequencer(course, prerequisites, visited, indegree, result)

    if len(result) == n:
        out.write(" ".join(result))

    else:
        out.write("IMPOSSIBLE")


inp = open("input1a.txt", "r")
out = open("output1a.txt", "w")
n, e = map(int, inp.readline().split())
d = {}
l = []
for i in range(e):

    k = inp.readline().split()
    l.append(k)
    if l[i][0] not in d:
        d[l[i][0]] = [l[i][1]]
    else:
        d[l[i][0]].append(l[i][1])

dfs_course_sequencer(n, d)


out.close()
